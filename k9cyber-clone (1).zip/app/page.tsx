import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Shield } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Shield className="w-6 h-6 text-cyan-400" />
          <span className="text-lg font-semibold">{"Plastiqhub"}</span>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#" className="text-gray-300 hover:text-white transition-colors">
            Home
          </a>
          <a href="#" className="text-gray-300 hover:text-white transition-colors">
            Products
          </a>
          <a href="#" className="text-gray-300 hover:text-white transition-colors">
            Contact
          </a>
          <a href="#" className="text-gray-300 hover:text-white transition-colors">
            Reviews
          </a>
        </nav>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 bg-transparent">
            Contact us
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 px-6">
        <h1 className="text-6xl md:text-8xl font-bold mb-4 tracking-wider">{"Plastiqhub"}</h1>
        <p className="text-xl text-gray-400 mb-8 tracking-wide">{"All your cards in one place "}</p>
        <Button className="bg-gray-800 hover:bg-gray-700 text-white px-8 py-3 rounded-md text-lg">CLICK TO SHOP</Button>

        {/* Rating */}
        <div className="mt-12 flex items-center justify-center gap-2">
          <span className="text-2xl font-bold">4.96</span>
          <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
        </div>
        <p className="text-gray-400 mt-1">Trusted</p>
      </section>

      {/* Products Section */}
      <section className="py-16 px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Products</h2>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-6 text-center">
              <div className="w-20 h-20 mx-auto mb-4 bg-gray-800 rounded-lg flex items-center justify-center">
                <Shield className="w-10 h-10 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Error bomber</h3>
              <p className="text-2xl font-bold text-cyan-400 mb-4">$30.00</p>
              <Button className="w-full bg-gray-800 hover:bg-gray-700">IN STOCK</Button>
            </CardContent>
          </Card>
        </div>
        <div className="text-center mt-8">
          <Button variant="link" className="text-cyan-400 hover:text-cyan-300">
            View all products →
          </Button>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-16 px-6 bg-gray-950">
        <h2 className="text-3xl font-bold text-center mb-12">Reviews</h2>
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((review) => (
            <Card key={review} className="bg-gray-900 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-gray-400 mb-2">a month ago</p>
                <p className="text-sm text-gray-300">Verified Purchase</p>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center mt-8">
          <Button variant="link" className="text-cyan-400 hover:text-cyan-300">
            See all reviews →
          </Button>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-16 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="bg-gray-800 border-gray-600">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">We're here to help</h2>
              <p className="text-gray-300 mb-6">
                If you're in need of support for a product you purchased or just want to say hello, don't hesitate to
                reach out!
              </p>
              <Button className="bg-gray-700 hover:bg-gray-600 text-white">Contact support</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-6 h-6 text-cyan-400" />
                <span className="text-lg font-semibold">K9 CYBER</span>
              </div>
              <p className="text-sm text-gray-400">CLICK TO SEE YOUR TOOLS</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-white">Help</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Products
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Reviews
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Support
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-white">Social</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Discord
                  </a>
                </li>
              </ul>
            </div>

            <div className="text-right">
              <p className="text-sm text-gray-400">Powered by</p>
              <p className="text-sm text-cyan-400 font-semibold">sellpass</p>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-sm text-gray-400">K9 CYBER © 2024</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
